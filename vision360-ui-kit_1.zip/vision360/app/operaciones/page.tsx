'use client'
import React from 'react'
import { RadialBarChart, RadialBar, PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'
import { PremiumCard }          from '@/components/ui/PremiumCard'
import { SleekDataTable }       from '@/components/ui/SleekDataTable'
import { NeonChartContainer, RECHARTS_THEME } from '@/components/ui/NeonChartContainer'
import { SectionDivider, InsightCard, DonutRing } from '@/components/ui/MicroComponents'
import { StatusBadge }          from '@/components/ui/StatusBadge'

/* ── DATOS DEMO ─────────────────────────────────────────── */
const SPARK_ENTREGA   = [72,74,73,76,78,80,82,81,83,85]
const SPARK_CANCEL    = [18,17,16,15,14,13,12,12,11,10]
const SPARK_CONFIRM   = [65,67,68,70,71,72,74,75,76,78]

const PEDIDOS_RECIENTES = [
  { id:'#8821', producto:'Crema Antiarrugas 50ml', cliente:'Bogotá',   valor:'$89.000', status:'entregado',  horas:'2h',  transportadora:'Servientrega' },
  { id:'#8820', producto:'Sérum Vitamina C',        cliente:'Medellín', valor:'$76.000', status:'procesando', horas:'5h',  transportadora:'Coordinadora' },
  { id:'#8819', producto:'Kit Facial Completo',     cliente:'Cali',     valor:'$145.000',status:'entregado',  horas:'8h',  transportadora:'Servientrega' },
  { id:'#8818', producto:'Crema Hidratante',        cliente:'Barranq.', valor:'$62.000', status:'pendiente',  horas:'12h', transportadora:'Envia' },
  { id:'#8817', producto:'Contorno de Ojos',        cliente:'Bogotá',   valor:'$94.000', status:'devolucion', horas:'24h', transportadora:'Servientrega' },
  { id:'#8816', producto:'Mascarilla Colágeno',     cliente:'Pereira',  valor:'$58.000', status:'entregado',  horas:'28h', transportadora:'TCC' },
  { id:'#8815', producto:'Sérum Retinol',           cliente:'Bucaraman.',valor:'$112.000',status:'cancelado', horas:'32h', transportadora:'Coordinadora' },
]

const TRANSPORTADORAS = [
  { nombre:'Servientrega', pedidos:248, entregados:221, tasa:'89.1%', tiempo:'2.4d', color:'#00F2FF' },
  { nombre:'Coordinadora', pedidos:186, entregados:158, tasa:'84.9%', tiempo:'2.8d', color:'#A855F7' },
  { nombre:'Envia',        pedidos:124, entregados:101, tasa:'81.5%', tiempo:'3.1d', color:'#00FF85' },
  { nombre:'TCC',          pedidos: 89, entregados: 71, tasa:'79.8%', tiempo:'3.6d', color:'#FFB020' },
  { nombre:'Inter Rapido', pedidos: 52, entregados: 39, tasa:'75.0%', tiempo:'4.2d', color:'#FF007F' },
]

const ESTATUS_PIE = [
  { name: 'Entregado',  value: 62, color: '#00FF85' },
  { name: 'Procesando', value: 18, color: '#00F2FF' },
  { name: 'Pendiente',  value: 10, color: '#FFB020' },
  { name: 'Devol.',     value:  6, color: '#FF3366' },
  { name: 'Cancelado',  value:  4, color: '#FF007F' },
]

/* ── PÁGINA ─────────────────────────────────────────────── */
export default function OperacionesPage() {
  return (
    <div style={{ padding: '28px 32px', maxWidth: 1400, margin: '0 auto' }}>

      {/* ── HEADER ── */}
      <div style={{ marginBottom: 28 }}>
        <div style={{
          fontFamily: 'var(--font-display)', fontSize: '1.7rem', fontWeight: 800,
          letterSpacing: '-0.04em', lineHeight: 1, marginBottom: 6,
          background: 'linear-gradient(100deg, #F0EEF8 0%, #FF007F 60%)',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
        }}>
          Centro de Operaciones
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.63rem', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.14em' }}>
          🤖 LUCID BOT · Tiempo real · 647 pedidos activos
        </div>
      </div>

      {/* ── KPI CARDS ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 24 }}>
        <PremiumCard title="Tasa de Entrega"      value="85.2%" trend={3.1}  icon="🚚" accent="emerald" sparkData={SPARK_ENTREGA}  animationDelay={0}   />
        <PremiumCard title="Tasa Confirmación"    value="78.4%" trend={2.8}  icon="✅" accent="cyan"    sparkData={SPARK_CONFIRM}  animationDelay={60}  />
        <PremiumCard title="Tasa Cancelación"     value="10.1%" trend={-2.4} icon="❌" accent="red"     sparkData={SPARK_CANCEL}   animationDelay={120} />
        <PremiumCard title="Tiempo Promedio"      value="2.7d"  trend={-8.2} icon="⏱" accent="amber"   sparkData={[3.5,3.2,3.0,2.9,2.8,2.7,2.7]} animationDelay={180} />
      </div>

      {/* ── DONUT RINGS + PIE ── */}
      <SectionDivider label="Distribución de estatus" accent="#FF007F" />
      <div style={{
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24,
      }}>
        {/* Donuts */}
        <div style={{
          background: 'rgba(255,255,255,0.022)',
          backdropFilter: 'blur(24px)', WebkitBackdropFilter: 'blur(24px)',
          border: '1px solid rgba(255,255,255,0.05)',
          borderRadius: 'var(--r-xl)', padding: '24px',
        }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.92rem', fontWeight: 700, color: 'var(--text-1)', marginBottom: 4 }}>
            Indicadores de Eficiencia
          </div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 24 }}>
            Tasas clave · últimos 30 días
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, justifyItems: 'center' }}>
            <DonutRing value={85.2} label="Entrega"     sublabel="Meta: 88%"  color="#00FF85" size={110} />
            <DonutRing value={78.4} label="Confirmac."  sublabel="Meta: 80%"  color="#00F2FF" size={110} />
            <DonutRing value={10.1} label="Cancelac."   sublabel="Meta: <8%"  color="#FF3366" size={110} />
            <DonutRing value={93.0} label="Satisfacción"sublabel="NPS: 72"    color="#A855F7" size={110} />
          </div>
        </div>

        {/* Pie de estatus */}
        <NeonChartContainer
          title="Estatus de Pedidos"
          subtitle="Distribución porcentual"
          accent="magenta"
          height={240}
          animationDelay={100}
        >
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={ESTATUS_PIE} cx="50%" cy="50%"
                innerRadius="52%" outerRadius="78%"
                paddingAngle={3} dataKey="value"
              >
                {ESTATUS_PIE.map((entry, i) => (
                  <Cell
                    key={i} fill={entry.color}
                    style={{ filter: `drop-shadow(0 0 10px ${entry.color}66)` }}
                  />
                ))}
              </Pie>
              <Tooltip
                {...RECHARTS_THEME.Tooltip}
                formatter={(v: number, name: string) => [`${v}%`, name]}
              />
            </PieChart>
          </ResponsiveContainer>
          {/* Leyenda manual */}
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap', paddingTop: 8 }}>
            {ESTATUS_PIE.map((e, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 7, height: 7, borderRadius: '50%', background: e.color, boxShadow: `0 0 8px ${e.color}` }} />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.62rem', color: 'var(--text-2)' }}>
                  {e.name} {e.value}%
                </span>
              </div>
            ))}
          </div>
        </NeonChartContainer>
      </div>

      {/* ── TABLA PEDIDOS ── */}
      <SectionDivider label="Pedidos recientes" accent="#00F2FF" />
      <SleekDataTable
        title="Flujo de Pedidos COD"
        subtitle="Últimas 48 horas · COP"
        searchable
        accent="cyan"
        animationDelay={150}
        columns={[
          { key: 'id',             header: 'ID',        width: '70px' },
          { key: 'producto',       header: 'Producto',  width: '2fr' },
          { key: 'cliente',        header: 'Ciudad',    width: '100px' },
          { key: 'valor',          header: 'Valor',     width: '100px', align: 'right',
            render: v => <span style={{ color:'#00F2FF', fontFamily:'var(--font-mono)', fontWeight:700 }}>{String(v)}</span> },
          { key: 'status',         header: 'Estado',    width: '130px', align: 'center', isBadge: true, badgeVariantKey: 'status' },
          { key: 'transportadora', header: 'Carrier',   width: '120px',
            render: v => <span style={{ color:'var(--text-2)', fontFamily:'var(--font-mono)', fontSize:'0.72rem' }}>{String(v)}</span> },
          { key: 'horas',          header: 'Hace',      width: '60px', align: 'right',
            render: v => <span style={{ color:'var(--text-3)', fontFamily:'var(--font-mono)', fontSize:'0.72rem' }}>{String(v)}</span> },
        ]}
        data={PEDIDOS_RECIENTES}
      />

      {/* ── TABLA TRANSPORTADORAS ── */}
      <SectionDivider label="Rendimiento por transportadora" accent="#A855F7" />
      <SleekDataTable
        title="Panel de Transportadoras"
        subtitle="Tasa de entrega · mes actual"
        accent="purple"
        animationDelay={200}
        columns={[
          { key: 'nombre',     header: 'Transportadora', width: '1.5fr',
            render: (v, row) => (
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ width:8, height:8, borderRadius:'50%', background:(row as typeof TRANSPORTADORAS[0]).color, boxShadow:`0 0 10px ${(row as typeof TRANSPORTADORAS[0]).color}`, flexShrink:0 }} />
                <span style={{ fontWeight:700, color:'var(--text-1)' }}>{String(v)}</span>
              </div>
            )},
          { key: 'pedidos',    header: 'Pedidos',   width: '80px', align:'right' },
          { key: 'entregados', header: 'Entregados',width: '80px', align:'right',
            render: v => <span style={{ color:'#00FF85' }}>{String(v)}</span> },
          { key: 'tasa',       header: 'Tasa',      width: '80px', align:'center',
            render: (v, row) => {
              const pct = parseFloat(String(v))
              const color = pct >= 88 ? '#00FF85' : pct >= 82 ? '#FFB020' : '#FF3366'
              return (
                <div>
                  <div style={{ color, fontFamily:'var(--font-mono)', fontWeight:700, fontSize:'0.82rem' }}>{String(v)}</div>
                  <div style={{ height:3, background:'rgba(255,255,255,0.06)', borderRadius:4, marginTop:4, overflow:'hidden' }}>
                    <div style={{ height:'100%', width:`${pct}%`, background:color, borderRadius:4, boxShadow:`0 0 8px ${color}55` }} />
                  </div>
                </div>
              )
            }},
          { key: 'tiempo',     header: 'T. Promedio', width: '90px', align:'center',
            render: v => <span style={{ color:'var(--text-2)', fontFamily:'var(--font-mono)' }}>{String(v)}</span> },
        ]}
        data={TRANSPORTADORAS}
      />

      {/* ── INSIGHTS ── */}
      <SectionDivider label="Alertas operativas" accent="#FF007F" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
        <InsightCard icon="✅" title="Entrega en alza" body="La tasa de entrega subió 3.1pp vs mes anterior. Servientrega lidera con 89.1%, seguida por Coordinadora." accent="emerald" />
        <InsightCard icon="⚠️" title="Inter Rapido: alerta" body="Tasa de 75% está por debajo del umbral mínimo (80%). Se recomienda reducir volumen asignado un 30%." accent="amber" />
        <InsightCard icon="🎯" title="Optimización COD" body="El 78.4% de confirmación puede mejorar con llamadas proactivas en primeras 2 horas post-pedido." accent="cyan" />
      </div>

      <div style={{ height: 40 }} />
    </div>
  )
}
