'use client'
import React, { useState } from 'react'
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, Cell,
} from 'recharts'
import { PremiumCard }          from '@/components/ui/PremiumCard'
import { SleekDataTable }       from '@/components/ui/SleekDataTable'
import { NeonChartContainer, RECHARTS_THEME } from '@/components/ui/NeonChartContainer'
import { SectionDivider, InsightCard, KpiRow } from '@/components/ui/MicroComponents'
import { StatusBadge }          from '@/components/ui/StatusBadge'

/* ── DATOS DEMO ─────────────────────────────────────────── */
const MESES = ['Sep','Oct','Nov','Dic','Ene','Feb','Mar']

const EVOLUCION = MESES.map((mes, i) => ({
  mes,
  ventas:   18 + i * 3.4 + (Math.random() * 4 - 2),
  ganancia: 5  + i * 1.1 + (Math.random() * 2 - 1),
  flete:    2.8 + i * 0.3,
  pauta:    1.2 + i * 0.15,
})).map(d => ({
  ...d,
  ventas:   +d.ventas.toFixed(1),
  ganancia: +d.ganancia.toFixed(1),
  flete:    +d.flete.toFixed(1),
  pauta:    +d.pauta.toFixed(1),
}))

const WATERFALL_DATA = [
  { name: 'Ingresos',          value: 38.4, type: 'income',   color: '#00FF85' },
  { name: 'Costo producto',    value:-14.2, type: 'expense',  color: '#FF3366' },
  { name: 'Fletes',            value: -5.8, type: 'expense',  color: '#FF007F' },
  { name: 'Pauta publicitaria',value: -3.1, type: 'expense',  color: '#FF007F' },
  { name: 'Otros costos',      value: -1.4, type: 'expense',  color: '#FF007F' },
  { name: 'Utilidad Neta',     value: 13.9, type: 'total',    color: '#00F2FF' },
]

const DETALLE_TABLA = [
  { periodo:'Mar 2025', ingresos:'$38.4M', costo_prod:'$14.2M', fletes:'$5.8M', pauta:'$3.1M', utilidad:'+$13.9M', margen:'36.2%', status:'ganancia', tendencia: 'cyan' },
  { periodo:'Feb 2025', ingresos:'$34.1M', costo_prod:'$12.8M', fletes:'$5.1M', pauta:'$2.9M', utilidad:'+$11.4M', margen:'33.4%', status:'ganancia', tendencia: 'emerald' },
  { periodo:'Ene 2025', ingresos:'$30.8M', costo_prod:'$11.6M', fletes:'$4.6M', pauta:'$2.6M', utilidad:'+$10.1M', margen:'32.8%', status:'ganancia', tendencia: 'emerald' },
  { periodo:'Dic 2024', ingresos:'$28.2M', costo_prod:'$12.1M', fletes:'$5.0M', pauta:'$3.2M', utilidad: '+$7.1M', margen:'25.2%', status:'ganancia', tendencia: 'amber' },
  { periodo:'Nov 2024', ingresos:'$24.6M', costo_prod:'$10.8M', fletes:'$4.2M', pauta:'$2.8M', utilidad: '+$5.8M', margen:'23.6%', status:'ganancia', tendencia: 'amber' },
  { periodo:'Oct 2024', ingresos:'$21.3M', costo_prod:'$10.2M', fletes:'$4.0M', pauta:'$2.4M', utilidad: '+$3.5M', margen:'16.4%', status:'pendiente', tendencia: 'amber' },
  { periodo:'Sep 2024', ingresos:'$18.0M', costo_prod:'$9.4M',  fletes:'$3.6M', pauta:'$2.1M', utilidad: '+$1.9M', margen:'10.6%', status:'pendiente', tendencia: 'red'   },
]

const SPARK_VENTAS   = EVOLUCION.map(d => d.ventas)
const SPARK_GANANCIA = EVOLUCION.map(d => d.ganancia)

const PERIODOS = ['Últimos 7 meses', '6 meses', '3 meses', 'Este mes']

/* ── COMPONENTE PRINCIPAL ───────────────────────────────── */
export default function FinanzasPGPage() {
  const [periodo, setPeriodo] = useState(0)

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1400, margin: '0 auto' }}>

      {/* ── PAGE HEADER ── */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 28 }}>
        <div>
          <div style={{
            fontFamily: 'var(--font-display)', fontSize: '1.7rem', fontWeight: 800,
            letterSpacing: '-0.04em', lineHeight: 1, marginBottom: 6,
            background: 'linear-gradient(100deg, #F0EEF8 0%, #00F2FF 55%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
          }}>
            Pérdidas & Ganancias
          </div>
          <div style={{
            fontFamily: 'var(--font-mono)', fontSize: '0.63rem',
            color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.14em',
          }}>
            🤖 LUCID BOT · COP · Actualizado hace 5 min
          </div>
        </div>

        {/* Selector de período */}
        <div style={{
          display: 'flex', gap: 4, background: 'rgba(255,255,255,0.03)',
          border: '1px solid rgba(255,255,255,0.05)', borderRadius: 14, padding: 4,
        }}>
          {PERIODOS.map((p, i) => (
            <button
              key={i}
              onClick={() => setPeriodo(i)}
              style={{
                padding: '6px 14px', borderRadius: 10, border: 'none', cursor: 'pointer',
                background: periodo === i ? 'rgba(0,242,255,0.1)' : 'transparent',
                color: periodo === i ? '#00F2FF' : 'var(--text-3)',
                fontFamily: 'var(--font-mono)', fontSize: '0.68rem', fontWeight: 600,
                transition: 'all 0.18s',
                boxShadow: periodo === i ? '0 0 16px rgba(0,242,255,0.1)' : 'none',
              }}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* ── KPI ROW SUPERIOR ── */}
      <KpiRow items={[
        { label: 'Ingresos totales',  value: '$38.4M', color: '#00F2FF' },
        { label: 'Costo total',       value: '$24.5M', color: '#FF3366' },
        { label: 'Utilidad neta',     value: '$13.9M', color: '#00FF85' },
        { label: 'Margen neto',       value: '36.2%',  color: '#A855F7' },
        { label: 'ROAS',              value: '3.1x',   color: '#FFB020' },
      ]} />

      {/* ── PREMIUM CARDS ── */}
      <SectionDivider label="Métricas clave del período" accent="#00F2FF" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 24 }}>
        <PremiumCard title="Ingresos Totales"   value="$38.4M" trend={12.6} icon="💰" accent="cyan"    sparkData={SPARK_VENTAS}   animationDelay={0}   />
        <PremiumCard title="Costo de Producto"  value="$14.2M" trend={8.3}  icon="📦" accent="red"     sparkData={[14,13,15,14,15,16,14]} animationDelay={60}  />
        <PremiumCard title="Pauta Publicitaria" value="$3.1M"  trend={-4.2} icon="📣" accent="magenta" sparkData={[3.2,2.9,3.1,3.4,2.8,3.0,3.1]} animationDelay={120} />
        <PremiumCard title="Utilidad Neta"      value="$13.9M" trend={18.4} icon="📈" accent="emerald" sparkData={SPARK_GANANCIA}  animationDelay={180} />
      </div>

      {/* ── GRÁFICOS ── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 16, marginBottom: 24 }}>

        {/* Evolución mensual */}
        <NeonChartContainer
          title="Evolución Mensual"
          subtitle="Ingresos vs Ganancia — Millones COP"
          accent="cyan"
          height={280}
          animationDelay={100}
          badge="7 meses"
        >
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={EVOLUCION} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="gradVentas" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00F2FF" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#00F2FF" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="gradGanancia" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00FF85" stopOpacity="0.20" />
                  <stop offset="100%" stopColor="#00FF85" stopOpacity="0" />
                </linearGradient>
              </defs>
              <CartesianGrid {...RECHARTS_THEME.CartesianGrid} />
              <XAxis dataKey="mes" {...RECHARTS_THEME.XAxis} />
              <YAxis {...RECHARTS_THEME.YAxis} tickFormatter={v => `$${v}M`} />
              <Tooltip {...RECHARTS_THEME.Tooltip} formatter={(v: number) => [`$${v}M`, '']} />
              <Area type="monotone" dataKey="ventas"   name="Ingresos"  stroke="#00F2FF" strokeWidth={2.5} fill="url(#gradVentas)"   dot={false} />
              <Area type="monotone" dataKey="ganancia" name="Ganancia"  stroke="#00FF85" strokeWidth={2.5} fill="url(#gradGanancia)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </NeonChartContainer>

        {/* Waterfall — Desglose del dinero */}
        <NeonChartContainer
          title="¿A dónde va el dinero?"
          subtitle="Desglose de costos — Mar 2025"
          accent="magenta"
          height={280}
          animationDelay={150}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={WATERFALL_DATA} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid {...RECHARTS_THEME.CartesianGrid} />
              <XAxis
                dataKey="name"
                tick={{ fill: '#3D3D55', fontFamily: 'DM Mono, monospace', fontSize: 9 }}
                axisLine={false} tickLine={false}
                interval={0} angle={-35} textAnchor="end" height={55}
              />
              <YAxis {...RECHARTS_THEME.YAxis} tickFormatter={v => `${v}M`} />
              <Tooltip {...RECHARTS_THEME.Tooltip} formatter={(v: number) => [`$${Math.abs(v)}M`, '']} />
              <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={40}>
                {WATERFALL_DATA.map((entry, i) => (
                  <Cell
                    key={i}
                    fill={entry.color}
                    style={{ filter: `drop-shadow(0 0 8px ${entry.color}55)` }}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </NeonChartContainer>
      </div>

      {/* Costos apilados */}
      <NeonChartContainer
        title="Costos Apilados vs Ingresos"
        subtitle="Mes a mes — Millones COP"
        accent="purple"
        height={240}
        animationDelay={200}
      >
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={EVOLUCION} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid {...RECHARTS_THEME.CartesianGrid} />
            <XAxis dataKey="mes" {...RECHARTS_THEME.XAxis} />
            <YAxis {...RECHARTS_THEME.YAxis} tickFormatter={v => `$${v}M`} />
            <Tooltip {...RECHARTS_THEME.Tooltip} formatter={(v: number) => [`$${v}M`, '']} />
            <Legend {...RECHARTS_THEME.Legend} />
            <Bar dataKey="flete"    name="Flete"    stackId="costs" fill="#FF007F" fillOpacity={0.85} radius={[0,0,0,0]} />
            <Bar dataKey="pauta"    name="Pauta"    stackId="costs" fill="#A855F7" fillOpacity={0.85} />
            <Bar dataKey="ganancia" name="Ganancia" stackId="costs" fill="#00FF85" fillOpacity={0.90} radius={[4,4,0,0]} />
            <Line type="monotone"   dataKey="ventas" name="Ingresos" stroke="#00F2FF" strokeWidth={2.5} dot={{ fill:'#00F2FF', r:3 }} yAxisId={0} />
          </BarChart>
        </ResponsiveContainer>
      </NeonChartContainer>

      {/* ── TABLA DETALLE ── */}
      <SectionDivider label="Historial por período" accent="#A855F7" />

      <SleekDataTable
        title="Desglose Financiero Mensual"
        subtitle="Todos los períodos · Millones COP"
        searchable
        accent="purple"
        animationDelay={250}
        columns={[
          { key: 'periodo',   header: 'Período',   width: '110px' },
          { key: 'ingresos',  header: 'Ingresos',  width: '100px', align: 'right',
            render: (v) => <span style={{ color:'#00F2FF', fontFamily:'var(--font-mono)', fontWeight:700 }}>{String(v)}</span> },
          { key: 'costo_prod',header: 'Costo Prod', width: '100px', align: 'right',
            render: (v) => <span style={{ color:'#FF3366', fontFamily:'var(--font-mono)' }}>{String(v)}</span> },
          { key: 'fletes',    header: 'Fletes',    width: '90px',  align: 'right',
            render: (v) => <span style={{ color:'#FF007F', fontFamily:'var(--font-mono)' }}>{String(v)}</span> },
          { key: 'pauta',     header: 'Pauta',     width: '90px',  align: 'right',
            render: (v) => <span style={{ color:'#A855F7', fontFamily:'var(--font-mono)' }}>{String(v)}</span> },
          { key: 'utilidad',  header: 'Utilidad',  width: '100px', align: 'right',
            render: (v) => <span style={{ color:'#00FF85', fontFamily:'var(--font-mono)', fontWeight:700 }}>{String(v)}</span> },
          { key: 'margen',    header: 'Margen',    width: '80px',  align: 'center',
            render: (v) => <span style={{ color:'#FFB020', fontFamily:'var(--font-mono)' }}>{String(v)}</span> },
          { key: 'status',    header: 'Estado',    width: '120px', align: 'center',
            isBadge: true, badgeVariantKey: 'status' },
        ]}
        data={DETALLE_TABLA}
      />

      {/* ── INSIGHTS ── */}
      <SectionDivider label="Análisis inteligente" accent="#00FF85" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
        <InsightCard
          icon="🚀"
          title="Crecimiento acelerado"
          body="Los ingresos crecieron +113% en 7 meses. El margen neto mejoró de 10.6% a 36.2%, señal de economías de escala."
          accent="emerald"
        />
        <InsightCard
          icon="⚠️"
          title="Oportunidad en fletes"
          body="Los fletes representan el 15.1% de los ingresos. Negociar tarifas por volumen podría recuperar $1.2M/mes."
          accent="amber"
        />
        <InsightCard
          icon="📊"
          title="ROAS positivo"
          body="Con $3.1M en pauta se generaron $38.4M en ingresos. ROAS de 3.1x supera el benchmark del sector (2.4x)."
          accent="cyan"
        />
      </div>

      <div style={{ height: 40 }} />
    </div>
  )
}
