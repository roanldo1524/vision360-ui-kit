import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        void:    '#060409',
        base:    '#0B0914',
        surface: '#100d1a',
        cyan:    '#00F2FF',
        magenta: '#FF007F',
        emerald: '#00FF85',
        amber:   '#FFB020',
        nred:    '#FF3366',
        purple:  '#A855F7',
      },
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        body:    ['Cabinet Grotesk', 'sans-serif'],
        mono:    ['DM Mono', 'monospace'],
      },
      backdropBlur: {
        glass: '28px',
      },
      boxShadow: {
        'glow-c': '0 0 40px rgba(0,242,255,0.12), 0 0 120px rgba(0,242,255,0.04)',
        'glow-m': '0 0 40px rgba(255,0,127,0.12), 0 0 120px rgba(255,0,127,0.04)',
        'glow-e': '0 0 40px rgba(0,255,133,0.12), 0 0 120px rgba(0,255,133,0.04)',
      },
    },
  },
  plugins: [],
}
export default config
