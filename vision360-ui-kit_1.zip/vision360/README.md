# 🌐 VISIÓN360 — UI Kit v2.0

Sistema de diseño modular para migrar Streamlit → Next.js/React.  
Estética: **Dark void / Glassmorphism / Neón**

---

## 📦 Instalación

```bash
npm install
npm run dev
```

---

## 🧱 Componentes (Los "Bloques Lego")

### `<PremiumCard />`
Tarjeta KPI con glassmorphism, minigráfico, tendencia y hover bounce.

```tsx
import { PremiumCard } from '@/components/ui'

<PremiumCard
  title="Utilidad Neta"
  value="$13.9M"
  trend={18.4}              // positivo = verde, negativo = rojo
  trendLabel="vs mes ant."
  icon="📈"
  accent="emerald"          // cyan | magenta | emerald | amber | red | purple
  sparkData={[5,6,7,8,10,11,14]}  // opcional — minigráfico de fondo
  size="md"                 // sm | md | lg
  animationDelay={120}      // ms de delay para animación staggered
/>
```

---

### `<NeonChartContainer />`
Wrapper para cualquier gráfico Recharts. Elimina fondos y cuadrículas genéricas.

```tsx
import { NeonChartContainer, RECHARTS_THEME } from '@/components/ui'

<NeonChartContainer
  title="Evolución Mensual"
  subtitle="Ingresos — COP"
  accent="cyan"
  height={280}
  badge="En vivo"           // opcional
  action={<MySelector />}   // opcional — va en la cabecera derecha
>
  <ResponsiveContainer width="100%" height="100%">
    <AreaChart data={data}>
      <CartesianGrid {...RECHARTS_THEME.CartesianGrid} />
      <XAxis dataKey="mes"  {...RECHARTS_THEME.XAxis} />
      <YAxis               {...RECHARTS_THEME.YAxis} />
      <Tooltip             {...RECHARTS_THEME.Tooltip} />
      <Area dataKey="ventas" stroke="#00F2FF" fill="url(#gradVentas)" />
    </AreaChart>
  </ResponsiveContainer>
</NeonChartContainer>
```

---

### `<SleekDataTable />`
Tabla sin bordes con `StatusBadge`, celdas de dinero con color y búsqueda.

```tsx
import { SleekDataTable } from '@/components/ui'

<SleekDataTable
  title="Desglose Financiero"
  subtitle="Millones COP"
  searchable
  accent="purple"
  columns={[
    { key: 'periodo',  header: 'Período' },
    { key: 'ingresos', header: 'Ingresos', align: 'right',
      render: v => <span style={{ color:'#00F2FF' }}>{v}</span> },
    { key: 'status',   header: 'Estado', isBadge: true, badgeVariantKey: 'status' },
  ]}
  data={miData}
/>
```

---

### `<StatusBadge />`
Píldora de estado con dot pulsante.

```tsx
import { StatusBadge } from '@/components/ui'

<StatusBadge variant="entregado">Entregado</StatusBadge>
<StatusBadge variant="devolucion">Devolución</StatusBadge>
<StatusBadge variant="pendiente">Pendiente</StatusBadge>
// variantes: entregado | ganancia | devolucion | perdida | cancelado
//            procesando | pendiente | cyan | magenta | emerald | amber | red | purple
```

---

### `<DonutRing />` · `<InsightCard />` · `<SectionDivider />` · `<KpiRow />`

```tsx
import { DonutRing, InsightCard, SectionDivider, KpiRow } from '@/components/ui'

// Donut SVG puro (sin dependencias)
<DonutRing value={85.2} label="Entrega" sublabel="Meta: 88%" color="#00FF85" size={120} />

// Tarjeta de insight con borde lateral de color
<InsightCard icon="🚀" title="Crecimiento" body="Los ingresos crecieron +113%…" accent="emerald" />

// Separador de sección
<SectionDivider label="Métricas clave" accent="#00F2FF" />

// Fila de KPIs inline
<KpiRow items={[
  { label: 'Ingresos', value: '$38.4M', color: '#00F2FF' },
  { label: 'Margen',   value: '36.2%',  color: '#A855F7' },
]} />
```

---

## 🗂️ Estructura de archivos

```
vision360/
├── app/
│   ├── finanzas/page.tsx        ← Vista P&G completa
│   └── operaciones/page.tsx     ← Vista Operaciones completa
├── components/
│   ├── Layout.tsx               ← Sidebar + main wrapper
│   └── ui/
│       ├── index.ts             ← Barrel exports
│       ├── PremiumCard.tsx
│       ├── SparklineChart.tsx
│       ├── NeonChartContainer.tsx
│       ├── SleekDataTable.tsx
│       ├── StatusBadge.tsx
│       └── MicroComponents.tsx  ← DonutRing, InsightCard, KpiRow, SectionDivider
├── styles/
│   └── globals.css              ← Tokens CSS, animaciones, scrollbar
├── tailwind.config.ts
└── package.json
```

---

## 🎨 Paleta & Tokens CSS

| Variable         | Valor                      | Uso |
|-----------------|----------------------------|-----|
| `--bg-void`     | `#060409`                  | Fondo más oscuro |
| `--bg-base`     | `#0B0914`                  | Fondo principal |
| `--bg-glass`    | `rgba(255,255,255,0.032)`  | Cards |
| `--cyan`        | `#00F2FF`                  | Acento primario |
| `--magenta`     | `#FF007F`                  | Acento secundario |
| `--emerald`     | `#00FF85`                  | Positivo / éxito |
| `--amber`       | `#FFB020`                  | Advertencia |
| `--red`         | `#FF3366`                  | Negativo / error |
| `--font-display`| `Syne`                     | Títulos y números KPI |
| `--font-body`   | `Cabinet Grotesk`          | Texto general |
| `--font-mono`   | `DM Mono`                  | Labels, badges, tablas |
