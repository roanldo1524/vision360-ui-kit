'use client'
import React from 'react'

interface NeonChartContainerProps {
  title?: string
  subtitle?: string
  children: React.ReactNode
  accent?: 'cyan' | 'magenta' | 'emerald' | 'amber' | 'purple'
  height?: number | string
  action?: React.ReactNode  // botón o selector opcional en la cabecera
  badge?: string            // texto de badge (ej: "En vivo")
  animate?: boolean
  animationDelay?: number
}

const ACCENT_MAP = {
  cyan:    { color: '#00F2FF', dim: 'rgba(0,242,255,0.06)',   bar: 'linear-gradient(90deg,#00F2FF,#0088FF)' },
  magenta: { color: '#FF007F', dim: 'rgba(255,0,127,0.06)',   bar: 'linear-gradient(90deg,#FF007F,#FF3CAC)' },
  emerald: { color: '#00FF85', dim: 'rgba(0,255,133,0.06)',   bar: 'linear-gradient(90deg,#00FF85,#00E5CC)' },
  amber:   { color: '#FFB020', dim: 'rgba(255,176,32,0.06)',  bar: 'linear-gradient(90deg,#FFB020,#FF7A00)' },
  purple:  { color: '#A855F7', dim: 'rgba(168,85,247,0.06)', bar: 'linear-gradient(90deg,#A855F7,#6366f1)' },
}

export function NeonChartContainer({
  title, subtitle, children, accent = 'cyan',
  height = 320, action, badge, animate = true, animationDelay = 0,
}: NeonChartContainerProps) {
  const a = ACCENT_MAP[accent]

  return (
    <div
      className={animate ? 'animate-float-up' : ''}
      style={{
        animationDelay: `${animationDelay}ms`,
        background: 'rgba(255,255,255,0.022)',
        backdropFilter: 'blur(28px)',
        WebkitBackdropFilter: 'blur(28px)',
        border: '1px solid rgba(255,255,255,0.05)',
        borderRadius: 'var(--r-xl)',
        overflow: 'hidden',
        transition: 'border-color 0.3s',
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.09)' }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.05)' }}
    >
      {/* Top accent bar */}
      <div style={{ height: 2, background: a.bar }} />

      {/* Header */}
      {(title || action) && (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '18px 22px 0',
        }}>
          <div>
            {title && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 10,
              }}>
                <span style={{
                  fontFamily: 'var(--font-display)', fontSize: '0.95rem', fontWeight: 700,
                  color: 'var(--text-1)', letterSpacing: '-0.02em',
                }}>
                  {title}
                </span>
                {badge && (
                  <span style={{
                    padding: '2px 8px', borderRadius: 30,
                    background: a.dim, border: `1px solid ${a.color}33`,
                    color: a.color, fontSize: '0.6rem', fontWeight: 700,
                    fontFamily: 'var(--font-mono)', letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                  }}>
                    {badge}
                  </span>
                )}
              </div>
            )}
            {subtitle && (
              <div style={{
                fontSize: '0.67rem', color: 'var(--text-3)',
                fontFamily: 'var(--font-mono)', marginTop: 3,
                textTransform: 'uppercase', letterSpacing: '0.1em',
              }}>
                {subtitle}
              </div>
            )}
          </div>
          {action && <div>{action}</div>}
        </div>
      )}

      {/* Chart area */}
      <div style={{ padding: '12px 8px 8px', height }}>
        {children}
      </div>
    </div>
  )
}

/* ── Recharts theme helper — usar dentro de <ResponsiveContainer> ── */
export const RECHARTS_THEME = {
  CartesianGrid: {
    strokeDasharray: '3 3',
    stroke: 'rgba(255,255,255,0.04)',
    vertical: false,
  },
  XAxis: {
    tick: { fill: '#3D3D55', fontFamily: 'DM Mono, monospace', fontSize: 11 },
    axisLine: { stroke: 'rgba(255,255,255,0.04)' },
    tickLine: false,
  },
  YAxis: {
    tick: { fill: '#3D3D55', fontFamily: 'DM Mono, monospace', fontSize: 11 },
    axisLine: false,
    tickLine: false,
  },
  Tooltip: {
    contentStyle: {
      background: 'rgba(11,9,20,0.97)',
      border: '1px solid rgba(0,242,255,0.18)',
      borderRadius: 12,
      fontFamily: 'DM Mono, monospace',
      fontSize: 12,
      color: '#F0EEF8',
      boxShadow: '0 8px 40px rgba(0,0,0,0.6)',
    },
    labelStyle: { color: '#8B8BA0', marginBottom: 6, fontSize: 11 },
    cursor: { fill: 'rgba(255,255,255,0.03)' },
  },
  Legend: {
    wrapperStyle: {
      fontFamily: 'DM Mono, monospace', fontSize: 11,
      color: '#8B8BA0', paddingTop: 12,
    },
  },
}
