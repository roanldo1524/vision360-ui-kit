import React from 'react'

type BadgeVariant =
  | 'entregado' | 'ganancia' | 'activo'
  | 'devolucion' | 'perdida' | 'cancelado'
  | 'pendiente' | 'procesando'
  | 'cyan' | 'magenta' | 'emerald' | 'amber' | 'red' | 'purple'
  | string

interface StatusBadgeProps {
  variant: BadgeVariant
  children: React.ReactNode
  size?: 'sm' | 'md'
  dot?: boolean
}

const VARIANT_MAP: Record<string, { bg: string; text: string; border: string; dot: string }> = {
  entregado:  { bg:'rgba(0,255,133,0.08)',  text:'#00FF85', border:'rgba(0,255,133,0.18)',  dot:'#00FF85' },
  ganancia:   { bg:'rgba(0,255,133,0.08)',  text:'#00FF85', border:'rgba(0,255,133,0.18)',  dot:'#00FF85' },
  activo:     { bg:'rgba(0,255,133,0.08)',  text:'#66FFAA', border:'rgba(0,255,133,0.15)',  dot:'#00FF85' },
  devolucion: { bg:'rgba(255,51,102,0.08)', text:'#FF6688', border:'rgba(255,51,102,0.18)', dot:'#FF3366' },
  perdida:    { bg:'rgba(255,51,102,0.08)', text:'#FF6688', border:'rgba(255,51,102,0.18)', dot:'#FF3366' },
  cancelado:  { bg:'rgba(255,51,102,0.08)', text:'#FF6688', border:'rgba(255,51,102,0.18)', dot:'#FF3366' },
  pendiente:  { bg:'rgba(255,176,32,0.08)', text:'#FFB020', border:'rgba(255,176,32,0.18)', dot:'#FFB020' },
  procesando: { bg:'rgba(0,242,255,0.08)',  text:'#00F2FF', border:'rgba(0,242,255,0.18)',  dot:'#00F2FF' },
  cyan:       { bg:'rgba(0,242,255,0.08)',  text:'#00F2FF', border:'rgba(0,242,255,0.18)',  dot:'#00F2FF' },
  magenta:    { bg:'rgba(255,0,127,0.08)',  text:'#FF4D9F', border:'rgba(255,0,127,0.18)',  dot:'#FF007F' },
  emerald:    { bg:'rgba(0,255,133,0.08)',  text:'#00FF85', border:'rgba(0,255,133,0.18)',  dot:'#00FF85' },
  amber:      { bg:'rgba(255,176,32,0.08)', text:'#FFB020', border:'rgba(255,176,32,0.18)', dot:'#FFB020' },
  red:        { bg:'rgba(255,51,102,0.08)', text:'#FF6688', border:'rgba(255,51,102,0.18)', dot:'#FF3366' },
  purple:     { bg:'rgba(168,85,247,0.08)', text:'#C084FC', border:'rgba(168,85,247,0.18)', dot:'#A855F7' },
}

export function StatusBadge({ variant, children, size = 'md', dot = true }: StatusBadgeProps) {
  const style = VARIANT_MAP[variant] ?? VARIANT_MAP.cyan

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '5px',
        padding: size === 'sm' ? '2px 8px' : '3px 10px',
        borderRadius: '30px',
        background: style.bg,
        border: `1px solid ${style.border}`,
        color: style.text,
        fontSize: size === 'sm' ? '0.63rem' : '0.7rem',
        fontWeight: 700,
        fontFamily: 'var(--font-mono)',
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        whiteSpace: 'nowrap',
      }}
    >
      {dot && (
        <span
          style={{
            width: 5,
            height: 5,
            borderRadius: '50%',
            background: style.dot,
            boxShadow: `0 0 8px ${style.dot}`,
            flexShrink: 0,
            animation: 'pulse-dot 2s ease-in-out infinite',
          }}
        />
      )}
      {children}
    </span>
  )
}
