import React from 'react'

/* ─── SECTION DIVIDER ─────────────────────────────────────── */
interface SectionDividerProps {
  label: string
  accent?: string
}
export function SectionDivider({ label, accent = '#00F2FF' }: SectionDividerProps) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '32px 0 20px' }}>
      <div style={{ width: 6, height: 6, borderRadius: '50%', background: accent, boxShadow: `0 0 12px ${accent}` }} />
      <span style={{
        fontFamily: 'var(--font-mono)', fontSize: '0.6rem', fontWeight: 600,
        letterSpacing: '0.16em', textTransform: 'uppercase', color: 'var(--text-3)',
        whiteSpace: 'nowrap',
      }}>
        {label}
      </span>
      <div style={{ flex: 1, height: 1, background: `linear-gradient(90deg, ${accent}18, transparent)` }} />
    </div>
  )
}

/* ─── KPI ROW ─────────────────────────────────────────────── */
interface KpiRowItemProps {
  label: string
  value: string
  color?: string
}
interface KpiRowProps {
  items: KpiRowItemProps[]
}
export function KpiRow({ items }: KpiRowProps) {
  return (
    <div style={{
      display: 'flex', gap: 1,
      background: 'rgba(255,255,255,0.02)',
      border: '1px solid rgba(255,255,255,0.05)',
      borderRadius: 'var(--r-lg)', overflow: 'hidden',
    }}>
      {items.map((item, i) => (
        <div
          key={i}
          style={{
            flex: 1, padding: '14px 18px', textAlign: 'center',
            borderRight: i < items.length - 1 ? '1px solid rgba(255,255,255,0.04)' : 'none',
          }}
        >
          <div style={{
            fontFamily: 'var(--font-mono)', fontSize: '0.58rem',
            color: 'var(--text-3)', textTransform: 'uppercase',
            letterSpacing: '0.12em', marginBottom: 4,
          }}>
            {item.label}
          </div>
          <div style={{
            fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 800,
            color: item.color ?? 'var(--text-1)', letterSpacing: '-0.04em',
          }}>
            {item.value}
          </div>
        </div>
      ))}
    </div>
  )
}

/* ─── INSIGHT CARD ────────────────────────────────────────── */
interface InsightCardProps {
  icon?: string
  title: string
  body: string
  accent?: 'cyan' | 'magenta' | 'emerald' | 'amber'
}
const INSIGHT_ACCENT = {
  cyan:    { color:'#00F2FF', bg:'rgba(0,242,255,0.05)',  border:'rgba(0,242,255,0.12)'  },
  magenta: { color:'#FF007F', bg:'rgba(255,0,127,0.05)',  border:'rgba(255,0,127,0.12)'  },
  emerald: { color:'#00FF85', bg:'rgba(0,255,133,0.05)',  border:'rgba(0,255,133,0.12)'  },
  amber:   { color:'#FFB020', bg:'rgba(255,176,32,0.05)', border:'rgba(255,176,32,0.12)' },
}
export function InsightCard({ icon, title, body, accent = 'cyan' }: InsightCardProps) {
  const a = INSIGHT_ACCENT[accent]
  return (
    <div style={{
      background: a.bg, border: `1px solid ${a.border}`,
      borderRadius: 'var(--r-lg)', padding: '16px 20px',
      position: 'relative', overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', top: 0, left: 0, bottom: 0, width: 3,
        background: a.color, borderRadius: '12px 0 0 12px', opacity: 0.7,
      }} />
      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
        {icon && <span style={{ fontSize: '1.1rem', flexShrink: 0 }}>{icon}</span>}
        <div>
          <div style={{
            fontFamily: 'var(--font-display)', fontSize: '0.82rem',
            color: a.color, fontWeight: 700, marginBottom: 5,
          }}>
            {title}
          </div>
          <div style={{
            fontSize: '0.77rem', color: 'var(--text-2)',
            fontFamily: 'var(--font-body)', lineHeight: 1.65,
          }}>
            {body}
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─── DONUT RING (SVG puro) ───────────────────────────────── */
interface DonutRingProps {
  value: number   // 0–100
  label: string
  sublabel?: string
  color?: string
  size?: number
}
export function DonutRing({ value, label, sublabel, color = '#00F2FF', size = 120 }: DonutRingProps) {
  const r = (size - 18) / 2
  const circ = 2 * Math.PI * r
  const filled = (value / 100) * circ
  const cx = size / 2

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <div style={{ position: 'relative', width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          <circle cx={cx} cy={cx} r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth={9} />
          <circle
            cx={cx} cy={cx} r={r} fill="none"
            stroke={color} strokeWidth={9}
            strokeLinecap="round"
            strokeDasharray={`${filled} ${circ - filled}`}
            strokeDashoffset={circ / 4}
            style={{ filter: `drop-shadow(0 0 8px ${color}88)`, transition: 'stroke-dasharray 0.8s cubic-bezier(.34,1.56,.64,1)' }}
          />
        </svg>
        <div style={{
          position: 'absolute', inset: 0,
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
        }}>
          <span style={{
            fontFamily: 'var(--font-display)', fontSize: size > 100 ? '1.5rem' : '1.1rem',
            fontWeight: 800, color, letterSpacing: '-0.04em',
          }}>
            {value.toFixed(1)}%
          </span>
        </div>
      </div>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-1)' }}>
          {label}
        </div>
        {sublabel && (
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-3)', marginTop: 2 }}>
            {sublabel}
          </div>
        )}
      </div>
    </div>
  )
}
