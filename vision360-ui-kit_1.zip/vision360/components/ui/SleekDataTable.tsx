'use client'
import React, { useState } from 'react'
import { StatusBadge } from './StatusBadge'

export interface ColumnDef<T = Record<string, unknown>> {
  key: string
  header: string
  width?: string
  align?: 'left' | 'right' | 'center'
  render?: (value: unknown, row: T, index: number) => React.ReactNode
  isBadge?: boolean
  badgeVariantKey?: string  // key de la fila que determina el variant del badge
  isMoney?: boolean
  moneyPositiveKey?: string // key numérico para determinar color
}

interface SleekDataTableProps<T = Record<string, unknown>> {
  columns: ColumnDef<T>[]
  data: T[]
  title?: string
  subtitle?: string
  maxRows?: number         // colapsar después de N filas
  accent?: 'cyan' | 'magenta' | 'emerald' | 'amber' | 'purple'
  searchable?: boolean
  animate?: boolean
  animationDelay?: number
  emptyMessage?: string
}

const ACCENT_COLORS = {
  cyan:    '#00F2FF', magenta: '#FF007F', emerald: '#00FF85',
  amber:   '#FFB020', purple:  '#A855F7',
}

export function SleekDataTable<T extends Record<string, unknown>>({
  columns, data, title, subtitle, maxRows = 10, accent = 'cyan',
  searchable = false, animate = true, animationDelay = 0, emptyMessage = 'Sin datos',
}: SleekDataTableProps<T>) {
  const [search, setSearch] = useState('')
  const [expanded, setExpanded] = useState(false)
  const accentColor = ACCENT_COLORS[accent]

  const filtered = searchable && search
    ? data.filter(row => Object.values(row).some(v => String(v).toLowerCase().includes(search.toLowerCase())))
    : data

  const visible = expanded ? filtered : filtered.slice(0, maxRows)
  const hasMore = filtered.length > maxRows

  return (
    <div
      className={animate ? 'animate-float-up' : ''}
      style={{
        animationDelay: `${animationDelay}ms`,
        background: 'rgba(255,255,255,0.022)',
        backdropFilter: 'blur(24px)',
        WebkitBackdropFilter: 'blur(24px)',
        border: '1px solid rgba(255,255,255,0.05)',
        borderRadius: 'var(--r-xl)',
        overflow: 'hidden',
      }}
    >
      {/* Header de la tabla */}
      {(title || searchable) && (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '18px 22px 14px',
          borderBottom: '1px solid rgba(255,255,255,0.04)',
        }}>
          <div>
            {title && (
              <div style={{
                fontFamily: 'var(--font-display)', fontSize: '0.92rem', fontWeight: 700,
                color: 'var(--text-1)', letterSpacing: '-0.02em',
              }}>
                {title}
              </div>
            )}
            {subtitle && (
              <div style={{
                fontSize: '0.63rem', color: 'var(--text-3)', fontFamily: 'var(--font-mono)',
                marginTop: 2, textTransform: 'uppercase', letterSpacing: '0.1em',
              }}>
                {subtitle}
              </div>
            )}
          </div>
          {searchable && (
            <input
              type="text"
              placeholder="Buscar…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: `1px solid rgba(255,255,255,0.07)`,
                borderRadius: 10, padding: '6px 12px',
                color: 'var(--text-1)', fontFamily: 'var(--font-mono)',
                fontSize: '0.75rem', outline: 'none',
                transition: 'border-color 0.2s',
              }}
              onFocus={e => { e.currentTarget.style.borderColor = `${accentColor}44` }}
              onBlur={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.07)' }}
            />
          )}
        </div>
      )}

      {/* Cabecera de columnas */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: columns.map(c => c.width || '1fr').join(' '),
        padding: '8px 22px',
        background: 'rgba(255,255,255,0.015)',
        borderBottom: '1px solid rgba(255,255,255,0.04)',
        gap: 8,
      }}>
        {columns.map(col => (
          <div key={col.key} style={{
            fontSize: '0.58rem', fontFamily: 'var(--font-mono)', fontWeight: 600,
            textTransform: 'uppercase', letterSpacing: '0.12em',
            color: 'var(--text-3)',
            textAlign: col.align || 'left',
          }}>
            {col.header}
          </div>
        ))}
      </div>

      {/* Filas */}
      {visible.length === 0 ? (
        <div style={{ padding: '32px', textAlign: 'center', color: 'var(--text-3)', fontSize: '0.8rem', fontFamily: 'var(--font-mono)' }}>
          {emptyMessage}
        </div>
      ) : (
        visible.map((row, rowIdx) => (
          <div
            key={rowIdx}
            style={{
              display: 'grid',
              gridTemplateColumns: columns.map(c => c.width || '1fr').join(' '),
              padding: '11px 22px',
              gap: 8,
              borderBottom: rowIdx < visible.length - 1 ? '1px solid rgba(255,255,255,0.03)' : 'none',
              transition: 'background 0.15s',
            }}
            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.018)' }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent' }}
          >
            {columns.map(col => {
              const value = row[col.key]
              return (
                <div key={col.key} style={{
                  fontSize: '0.80rem', color: 'var(--text-1)',
                  fontFamily: col.isBadge || col.isMoney ? 'var(--font-mono)' : 'var(--font-body)',
                  textAlign: col.align || 'left',
                  display: 'flex',
                  justifyContent: col.align === 'right' ? 'flex-end' : col.align === 'center' ? 'center' : 'flex-start',
                  alignItems: 'center',
                }}>
                  {col.render
                    ? col.render(value, row, rowIdx)
                    : col.isBadge
                    ? <StatusBadge variant={(col.badgeVariantKey ? row[col.badgeVariantKey] : value) as string} size="sm">{String(value)}</StatusBadge>
                    : col.isMoney
                    ? <MoneyCell value={Number(value)} positiveKey={col.moneyPositiveKey ? Number(row[col.moneyPositiveKey]) : Number(value)} />
                    : <span>{String(value ?? '—')}</span>
                  }
                </div>
              )
            })}
          </div>
        ))
      )}

      {/* Ver más */}
      {hasMore && (
        <button
          onClick={() => setExpanded(!expanded)}
          style={{
            width: '100%', padding: '12px',
            background: 'rgba(255,255,255,0.02)',
            border: 'none', borderTop: '1px solid rgba(255,255,255,0.04)',
            color: accentColor, fontFamily: 'var(--font-mono)',
            fontSize: '0.68rem', fontWeight: 600, cursor: 'pointer',
            letterSpacing: '0.08em', textTransform: 'uppercase',
            transition: 'background 0.15s',
          }}
          onMouseEnter={e => { e.currentTarget.style.background = `${accentColor}08` }}
          onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.02)' }}
        >
          {expanded ? `▲ Mostrar menos` : `▼ Ver ${filtered.length - maxRows} más`}
        </button>
      )}
    </div>
  )
}

/* ── Celda de dinero con color ── */
function MoneyCell({ value, positiveKey }: { value: number; positiveKey: number }) {
  const isPositive = positiveKey >= 0
  return (
    <span style={{ color: isPositive ? '#00FF85' : '#FF3366', fontFamily: 'var(--font-mono)' }}>
      {isPositive ? '+' : ''}{value.toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 })}
    </span>
  )
}
