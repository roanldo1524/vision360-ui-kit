'use client'
import React from 'react'
import { SparklineChart } from './SparklineChart'

type AccentColor = 'cyan' | 'magenta' | 'emerald' | 'amber' | 'red' | 'purple'

interface PremiumCardProps {
  title: string
  value: string
  trend?: number        // porcentaje, ej: 12.4 o -3.2
  trendLabel?: string   // ej: "vs mes anterior"
  icon?: string         // emoji
  accent?: AccentColor
  sparkData?: number[]  // datos para el minigráfico
  size?: 'sm' | 'md' | 'lg'
  subtitle?: string
  animate?: boolean
  animationDelay?: number
}

const ACCENT: Record<AccentColor, {
  color: string; glow: string; dim: string;
  topBar: string; sparkColor: string
}> = {
  cyan:    { color:'#00F2FF', glow:'rgba(0,242,255,0.16)',  dim:'rgba(0,242,255,0.06)',  topBar:'linear-gradient(90deg,#00F2FF,#0088FF)', sparkColor:'#00F2FF' },
  magenta: { color:'#FF007F', glow:'rgba(255,0,127,0.16)',  dim:'rgba(255,0,127,0.06)',  topBar:'linear-gradient(90deg,#FF007F,#FF3CAC)', sparkColor:'#FF007F' },
  emerald: { color:'#00FF85', glow:'rgba(0,255,133,0.16)',  dim:'rgba(0,255,133,0.06)',  topBar:'linear-gradient(90deg,#00FF85,#00E5CC)', sparkColor:'#00FF85' },
  amber:   { color:'#FFB020', glow:'rgba(255,176,32,0.16)', dim:'rgba(255,176,32,0.06)', topBar:'linear-gradient(90deg,#FFB020,#FF7A00)', sparkColor:'#FFB020' },
  red:     { color:'#FF3366', glow:'rgba(255,51,102,0.16)', dim:'rgba(255,51,102,0.06)', topBar:'linear-gradient(90deg,#FF3366,#FF007F)', sparkColor:'#FF3366' },
  purple:  { color:'#A855F7', glow:'rgba(168,85,247,0.16)', dim:'rgba(168,85,247,0.06)', topBar:'linear-gradient(90deg,#A855F7,#6366f1)', sparkColor:'#A855F7' },
}

export function PremiumCard({
  title, value, trend, trendLabel = 'vs anterior',
  icon, accent = 'cyan', sparkData,
  size = 'md', subtitle, animate = true, animationDelay = 0,
}: PremiumCardProps) {
  const a = ACCENT[accent]
  const isPositive = (trend ?? 0) >= 0
  const trendColor = isPositive ? '#00FF85' : '#FF3366'
  const trendBg    = isPositive ? 'rgba(0,255,133,0.08)' : 'rgba(255,51,102,0.08)'
  const trendBorder = isPositive ? 'rgba(0,255,133,0.18)' : 'rgba(255,51,102,0.18)'

  const valueSizes = { sm: '1.6rem', md: '2.1rem', lg: '2.8rem' }
  const padding    = { sm: '16px', md: '22px', lg: '28px' }

  return (
    <div
      className={animate ? 'animate-float-up' : ''}
      style={{
        animationDelay: `${animationDelay}ms`,
        position: 'relative',
        background: 'rgba(255,255,255,0.028)',
        backdropFilter: 'blur(24px)',
        WebkitBackdropFilter: 'blur(24px)',
        border: '1px solid rgba(255,255,255,0.055)',
        borderRadius: 'var(--r-xl)',
        padding: padding[size],
        overflow: 'hidden',
        transition: 'transform 0.35s cubic-bezier(.34,1.56,.64,1), border-color 0.3s, box-shadow 0.3s',
        cursor: 'default',
      }}
      onMouseEnter={e => {
        const el = e.currentTarget
        el.style.transform = 'translateY(-6px)'
        el.style.borderColor = a.glow.replace('0.16', '0.30')
        el.style.boxShadow = `var(--shadow-md), 0 0 40px ${a.glow}`
      }}
      onMouseLeave={e => {
        const el = e.currentTarget
        el.style.transform = 'translateY(0)'
        el.style.borderColor = 'rgba(255,255,255,0.055)'
        el.style.boxShadow = 'none'
      }}
    >
      {/* Barra de color superior */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 2,
        background: a.topBar, borderRadius: '28px 28px 0 0',
      }} />

      {/* Brillo interior diagonal */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(145deg, rgba(255,255,255,0.03) 0%, transparent 55%)',
        borderRadius: 'inherit', pointerEvents: 'none',
      }} />

      {/* Halo de color de fondo */}
      <div style={{
        position: 'absolute', bottom: -20, right: -20,
        width: 120, height: 120, borderRadius: '50%',
        background: a.dim, filter: 'blur(40px)', pointerEvents: 'none',
      }} />

      {/* Sparkline de fondo si hay datos */}
      {sparkData && (
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: '55%', opacity: 0.15, pointerEvents: 'none' }}>
          <SparklineChart data={sparkData} color={a.sparkColor} />
        </div>
      )}

      {/* Contenido */}
      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* Header: título + icono */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
          <div>
            <div style={{
              fontFamily: 'var(--font-mono)', fontSize: '0.6rem', fontWeight: 500,
              color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.14em',
              marginBottom: 2,
            }}>
              {title}
            </div>
            {subtitle && (
              <div style={{ fontSize: '0.72rem', color: 'var(--text-2)', fontFamily: 'var(--font-mono)' }}>
                {subtitle}
              </div>
            )}
          </div>
          {icon && (
            <div style={{
              width: 36, height: 36, borderRadius: 10, flexShrink: 0,
              background: a.dim, border: `1px solid ${a.glow}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '1.1rem',
            }}>
              {icon}
            </div>
          )}
        </div>

        {/* Valor principal */}
        <div style={{
          fontFamily: 'var(--font-display)',
          fontSize: valueSizes[size],
          fontWeight: 800,
          color: 'var(--text-1)',
          letterSpacing: '-0.04em',
          lineHeight: 1,
          marginBottom: 10,
          textShadow: `0 2px 24px ${a.glow}`,
        }}>
          {value}
        </div>

        {/* Tendencia */}
        {trend !== undefined && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 3,
              padding: '2px 8px', borderRadius: 30,
              background: trendBg, border: `1px solid ${trendBorder}`,
              color: trendColor, fontSize: '0.68rem', fontWeight: 700,
              fontFamily: 'var(--font-mono)',
            }}>
              {isPositive ? '▲' : '▼'} {Math.abs(trend).toFixed(1)}%
            </span>
            <span style={{ fontSize: '0.65rem', color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>
              {trendLabel}
            </span>
          </div>
        )}
      </div>
    </div>
  )
}
