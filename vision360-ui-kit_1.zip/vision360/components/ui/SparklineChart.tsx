'use client'
import React from 'react'

interface SparklineChartProps {
  data: number[]
  color?: string
  height?: number
  strokeWidth?: number
  filled?: boolean
}

export function SparklineChart({
  data, color = '#00F2FF', height = 60, strokeWidth = 2, filled = true,
}: SparklineChartProps) {
  if (!data || data.length < 2) return null

  const width = 200
  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const pad = 4

  const points = data.map((v, i) => ({
    x: pad + (i / (data.length - 1)) * (width - pad * 2),
    y: pad + ((1 - (v - min) / range) * (height - pad * 2)),
  }))

  // Smooth cubic bezier path
  const pathD = points.reduce((acc, pt, i) => {
    if (i === 0) return `M ${pt.x},${pt.y}`
    const prev = points[i - 1]
    const cpx = (prev.x + pt.x) / 2
    return `${acc} C ${cpx},${prev.y} ${cpx},${pt.y} ${pt.x},${pt.y}`
  }, '')

  const fillD = `${pathD} L ${points[points.length-1].x},${height} L ${points[0].x},${height} Z`

  const gradId = `spark-grad-${color.replace('#','')}`

  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor={color} stopOpacity="0.4" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {filled && (
        <path d={fillD} fill={`url(#${gradId})`} />
      )}
      <path
        d={pathD}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}
