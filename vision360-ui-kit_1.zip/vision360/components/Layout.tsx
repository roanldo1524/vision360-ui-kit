'use client'
import React, { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const NAV_ITEMS = [
  { label: 'Panel Ejecutivo', href: '/',                icon: '◈', accent: '#00F2FF' },
  { label: 'P&G',             href: '/pg',              icon: '◐', accent: '#00F2FF' },
  { label: 'Finanzas',        href: '/finanzas',        icon: '◑', accent: '#00F2FF' },
  { label: 'Proyecciones',    href: '/proyecciones',    icon: '◒', accent: '#A855F7' },
  { label: 'Asesor IA',       href: '/asesor',          icon: '⬡', accent: '#A855F7' },
  { label: 'Tendencias',      href: '/tendencias',      icon: '◈', accent: '#A855F7' },
  { label: 'Operaciones',     href: '/operaciones',     icon: '▣', accent: '#FF007F' },
  { label: 'Monitor',         href: '/monitor',         icon: '▢', accent: '#FF007F' },
  { label: 'Marketing',       href: '/marketing',       icon: '◆', accent: '#FF007F' },
  { label: 'Catálogo',        href: '/catalogo',        icon: '▤', accent: '#FFB020' },
  { label: 'Asistente',       href: '/asistente',       icon: '◉', accent: '#FFB020' },
]

const NAV_SECTIONS = [
  { label: 'Analítica',  items: NAV_ITEMS.slice(0, 6)  },
  { label: 'Comercial',  items: NAV_ITEMS.slice(6, 9)  },
  { label: 'Gestión',    items: NAV_ITEMS.slice(9)      },
]

const STORES = ['🤖 LUCID BOT', '✨ ESSENTYA', '🐂 EL TORO', '🛒 Carrito Naranja', '🏪 BODEGA']

interface LayoutProps {
  children: React.ReactNode
}

export default function Layout({ children }: LayoutProps) {
  const pathname = usePathname()
  const [activeStore, setActiveStore] = useState(0)
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg-void)' }}>

      {/* ── SIDEBAR ── */}
      <aside style={{
        width: collapsed ? 64 : 240,
        minHeight: '100vh',
        background: 'linear-gradient(180deg, #0d0b18 0%, #0B0914 60%, #080611 100%)',
        borderRight: '1px solid rgba(255,255,255,0.04)',
        display: 'flex', flexDirection: 'column',
        transition: 'width 0.3s cubic-bezier(.34,1.56,.64,1)',
        position: 'sticky', top: 0, zIndex: 40,
        overflow: 'hidden', flexShrink: 0,
      }}>

        {/* Logo */}
        <div style={{
          padding: collapsed ? '20px 16px' : '22px 18px 14px',
          borderBottom: '1px solid rgba(255,255,255,0.04)',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10, flexShrink: 0,
            background: 'linear-gradient(135deg, #00F2FF, #00FF85)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1.0rem', filter: 'brightness(0)',
            boxShadow: '0 4px 20px rgba(0,242,255,0.3)',
          }}>
            🌐
          </div>
          {!collapsed && (
            <div>
              <div style={{
                fontFamily: 'var(--font-display)', fontSize: '1.0rem', fontWeight: 800,
                letterSpacing: '-0.04em', lineHeight: 1,
              }}>
                <span style={{ color: '#F0EEF8' }}>Visió</span>
                <span style={{
                  background: 'linear-gradient(90deg,#00F2FF,#00FF85)',
                  WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }}>N360</span>
              </div>
              <div style={{
                fontSize: '0.5rem', color: 'rgba(139,139,160,0.4)', fontWeight: 600,
                letterSpacing: '0.14em', textTransform: 'uppercase',
                fontFamily: 'var(--font-mono)', marginTop: 1,
              }}>
                Inteligencia Comercial
              </div>
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            style={{
              marginLeft: 'auto', background: 'none', border: 'none',
              color: 'var(--text-3)', cursor: 'pointer', fontSize: '0.7rem',
              padding: 4, borderRadius: 6, transition: 'color 0.2s',
              flexShrink: 0,
            }}
          >
            {collapsed ? '▶' : '◀'}
          </button>
        </div>

        {/* Store selector */}
        {!collapsed && (
          <div style={{ padding: '12px 14px 8px' }}>
            <div style={{
              fontSize: '0.55rem', color: 'var(--text-3)', fontFamily: 'var(--font-mono)',
              textTransform: 'uppercase', letterSpacing: '0.14em', marginBottom: 6,
            }}>
              Tienda activa
            </div>
            <select
              value={activeStore}
              onChange={e => setActiveStore(Number(e.target.value))}
              style={{
                width: '100%', background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(0,242,255,0.1)', borderRadius: 10,
                color: '#F0EEF8', fontFamily: 'var(--font-body)', fontSize: '0.78rem',
                fontWeight: 600, padding: '7px 10px', cursor: 'pointer', outline: 'none',
              }}
            >
              {STORES.map((s, i) => <option key={i} value={i}>{s}</option>)}
            </select>
          </div>
        )}

        {/* Nav sections */}
        <nav style={{ flex: 1, overflowY: 'auto', padding: '6px 8px' }}>
          {NAV_SECTIONS.map(section => (
            <div key={section.label} style={{ marginBottom: 4 }}>
              {!collapsed && (
                <div style={{
                  fontSize: '0.53rem', color: 'var(--text-3)', fontFamily: 'var(--font-mono)',
                  textTransform: 'uppercase', letterSpacing: '0.16em',
                  padding: '10px 8px 4px',
                }}>
                  {section.label}
                </div>
              )}
              {section.items.map(item => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 9,
                      padding: collapsed ? '10px 16px' : '8px 10px',
                      borderRadius: 10, textDecoration: 'none',
                      background: isActive ? `${item.accent}10` : 'transparent',
                      border: `1px solid ${isActive ? `${item.accent}20` : 'transparent'}`,
                      color: isActive ? item.accent : 'var(--text-2)',
                      fontSize: '0.80rem', fontWeight: isActive ? 700 : 500,
                      fontFamily: 'var(--font-body)',
                      transition: 'all 0.18s',
                      marginBottom: 1,
                    }}
                    onMouseEnter={e => {
                      if (!isActive) {
                        e.currentTarget.style.background = 'rgba(255,255,255,0.04)'
                        e.currentTarget.style.color = '#F0EEF8'
                      }
                    }}
                    onMouseLeave={e => {
                      if (!isActive) {
                        e.currentTarget.style.background = 'transparent'
                        e.currentTarget.style.color = 'var(--text-2)'
                      }
                    }}
                  >
                    <span style={{
                      fontSize: '0.85rem', flexShrink: 0,
                      color: isActive ? item.accent : 'var(--text-3)',
                    }}>
                      {item.icon}
                    </span>
                    {!collapsed && item.label}
                  </Link>
                )
              })}
            </div>
          ))}
        </nav>

        {/* Footer */}
        {!collapsed && (
          <div style={{
            padding: '12px 14px', borderTop: '1px solid rgba(255,255,255,0.04)',
            fontSize: '0.55rem', color: 'var(--text-3)', fontFamily: 'var(--font-mono)',
            textAlign: 'center', letterSpacing: '0.06em',
          }}>
            VISIÓN360 · v2.0 · 2025
          </div>
        )}
      </aside>

      {/* ── MAIN ── */}
      <main style={{ flex: 1, overflowX: 'hidden', minHeight: '100vh' }}>
        {children}
      </main>
    </div>
  )
}
